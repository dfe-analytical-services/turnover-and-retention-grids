#!/usr/bin/env Rscript

pkgdown::build_site()
