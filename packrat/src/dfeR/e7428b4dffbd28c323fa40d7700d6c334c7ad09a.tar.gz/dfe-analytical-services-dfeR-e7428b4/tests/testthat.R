library(testthat)
library(dfeR)

test_check("dfeR")
