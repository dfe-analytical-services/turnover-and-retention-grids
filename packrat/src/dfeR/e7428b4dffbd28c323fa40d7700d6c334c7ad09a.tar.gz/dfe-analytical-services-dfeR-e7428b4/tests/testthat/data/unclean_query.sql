Use ExampleDB

GO
  -- This is an example query
     Select  *   From -- Another comment
     ---- Double comment
     Schema.TableName

